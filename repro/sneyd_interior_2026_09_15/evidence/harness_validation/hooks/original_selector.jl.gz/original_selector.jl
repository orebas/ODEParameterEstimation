function sneyd_original_shooting_indices(n_points::Int, n_total::Int; warp::Bool = true, beta::Float64 = 3.0)
	n_total <= 0 && return Int[]
	n_total == 1 && return [1]
	n_total == 2 && return [1, 2]
	n_points <= 0 && return [max(1, n_total ÷ 2)]
	n_points == 1 && return [1]
	n_points >= n_total && return collect(1:n_total)

	if !warp || abs(beta) < 1e-10
		# Equidistant
		indices = round.(Int, range(1, n_total, length = n_points))
	else
		u = range(0.0, 1.0, length = n_points)
		frac = (exp.(beta .* u) .- 1) ./ (exp(beta) - 1)
		indices = round.(Int, 1 .+ frac .* (n_total - 1))
		indices = clamp.(indices, 1, n_total)
	end
	return unique(indices)
end
